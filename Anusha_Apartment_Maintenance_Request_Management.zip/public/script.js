const configs = {
    residents: {
        title: "Residents",
        key: "resident_id",
        fields: [
            ["resident_name", "Resident Name", "text", true],
            ["flat_no", "Flat Number", "text", true],
            ["phone", "Phone Number", "tel"],
            ["email", "Email", "email"]
        ]
    },
    maintenance_staff: {
        title: "Maintenance Staff",
        key: "staff_id",
        fields: [
            ["staff_name", "Staff Name", "text", true],
            ["job_role", "Job Role", "text"],
            ["phone", "Phone Number", "tel"],
            ["email", "Email", "email"]
        ]
    },
    requests: {
        title: "Maintenance Requests",
        key: "request_id",
        fields: [
            ["resident_id", "Resident ID", "number", true],
            ["staff_id", "Assigned Staff ID (optional)", "number"],
            ["request_title", "Request Title", "text", true],
            ["description", "Description", "textarea"],
            ["request_date", "Request Date", "date"],
            ["status", "Status", "select", false, ["Pending", "In Progress", "Completed", "Cancelled"]]
        ]
    },
    maintenance_records: {
        title: "Maintenance Records",
        key: "record_id",
        fields: [
            ["request_id", "Request ID", "number", true],
            ["work_description", "Work Description", "textarea"],
            ["completion_date", "Completion Date", "date"],
            ["repair_cost", "Repair Cost", "number"],
            ["remarks", "Remarks", "textarea"]
        ]
    }
};

let currentTable = "residents";
let editingId = null;
let currentRows = [];

const form = document.getElementById("recordForm");
const fieldsDiv = document.getElementById("fields");
const message = document.getElementById("message");

function showMessage(text) { message.textContent = text; }

function renderForm() {
    const config = configs[currentTable];
    fieldsDiv.innerHTML = "";
    config.fields.forEach(([name, label, type, required, options]) => {
        const wrapper = document.createElement("div");
        wrapper.className = "field";
        const labelEl = document.createElement("label");
        labelEl.htmlFor = name;
        labelEl.textContent = label;
        let input;
        if (type === "textarea") {
            input = document.createElement("textarea");
        } else if (type === "select") {
            input = document.createElement("select");
            options.forEach(option => {
                const opt = document.createElement("option");
                opt.value = option;
                opt.textContent = option;
                input.appendChild(opt);
            });
        } else {
            input = document.createElement("input");
            input.type = type;
            if (type === "number" && name === "repair_cost") input.step = "0.01";
        }
        input.id = name;
        input.name = name;
        input.required = !!required;
        wrapper.append(labelEl, input);
        fieldsDiv.appendChild(wrapper);
    });
    document.getElementById("tableTitle").textContent = config.title;
    document.getElementById("saveBtn").textContent = editingId ? "Update Record" : "Add Record";
}

function renderTable(rows) {
    currentRows = rows;
    const config = configs[currentTable];
    const columns = [config.key, ...config.fields.map(field => field[0])];
    const head = document.getElementById("tableHead");
    const body = document.getElementById("tableBody");
    head.innerHTML = `<tr>${columns.map(c => `<th>${escapeHtml(c)}</th>`).join("")}<th>Actions</th></tr>`;
    body.innerHTML = "";
    if (!rows.length) {
        body.innerHTML = `<tr><td class="empty" colspan="${columns.length + 1}">No records found</td></tr>`;
        return;
    }
    rows.forEach(row => {
        const tr = document.createElement("tr");
        columns.forEach(column => {
            const td = document.createElement("td");
            td.textContent = row[column] ?? "";
            tr.appendChild(td);
        });
        const actions = document.createElement("td");
        const edit = document.createElement("button");
        edit.textContent = "Edit";
        edit.addEventListener("click", () => startEdit(row));
        const del = document.createElement("button");
        del.textContent = "Delete";
        del.className = "delete";
        del.addEventListener("click", () => deleteRow(row[config.key]));
        actions.append(edit, del);
        tr.appendChild(actions);
        body.appendChild(tr);
    });
}

function escapeHtml(value) {
    return String(value).replace(/[&<>"']/g, char => ({
        "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
    }[char]));
}

async function loadRows() {
    try {
        const response = await fetch(`/api/${currentTable}`);
        const data = await response.json();
        if (!response.ok) throw new Error(data.error || "Unable to load records");
        renderTable(data);
        showMessage("");
    } catch (error) {
        showMessage(error.message);
        renderTable([]);
    }
}

function startEdit(row) {
    editingId = row[configs[currentTable].key];
    configs[currentTable].fields.forEach(([name]) => {
        const input = document.getElementById(name);
        input.value = row[name] ?? "";
    });
    document.getElementById("saveBtn").textContent = "Update Record";
    document.getElementById("cancelBtn").hidden = false;
    showMessage(`Editing record ${editingId}`);
    form.scrollIntoView({ behavior: "smooth", block: "center" });
}

function resetForm() {
    editingId = null;
    form.reset();
    document.getElementById("saveBtn").textContent = "Add Record";
    document.getElementById("cancelBtn").hidden = true;
}

form.addEventListener("submit", async event => {
    event.preventDefault();
    const data = {};
    configs[currentTable].fields.forEach(([name]) => {
        data[name] = document.getElementById(name).value;
    });
    const url = editingId
        ? `/api/${currentTable}/${editingId}`
        : `/api/${currentTable}`;
    try {
        const response = await fetch(url, {
            method: editingId ? "PUT" : "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(data)
        });
        const result = await response.json();
        if (!response.ok) throw new Error(result.error || "Operation failed");
        showMessage(result.message);
        resetForm();
        loadRows();
    } catch (error) {
        showMessage(error.message);
    }
});

async function deleteRow(id) {
    if (!confirm("Are you sure you want to delete this record?")) return;
    try {
        const response = await fetch(`/api/${currentTable}/${id}`, { method: "DELETE" });
        const result = await response.json();
        if (!response.ok) throw new Error(result.error || "Delete failed");
        showMessage(result.message);
        loadRows();
    } catch (error) {
        showMessage(error.message);
    }
}

document.getElementById("cancelBtn").addEventListener("click", resetForm);
document.getElementById("refreshBtn").addEventListener("click", loadRows);
document.querySelectorAll("#tabs button").forEach(button => {
    button.addEventListener("click", () => {
        currentTable = button.dataset.table;
        editingId = null;
        resetForm();
        document.querySelectorAll("#tabs button").forEach(b => b.classList.toggle("active", b === button));
        renderForm();
        loadRows();
    });
});

renderForm();
loadRows();
